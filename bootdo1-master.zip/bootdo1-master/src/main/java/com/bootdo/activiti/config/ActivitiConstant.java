package com.bootdo.activiti.config;

/**

 */
public class ActivitiConstant {
    public static final String[] ACTIVITI_SALARY = new String[]{"salary","salary"};
}
